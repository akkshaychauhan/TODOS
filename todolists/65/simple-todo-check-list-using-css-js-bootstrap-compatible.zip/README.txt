A Pen created at CodePen.io. You can find this one at https://codepen.io/mrdogra007/pen/JObKme.

 Simple ToDo check list using CSS & JS - Bootstrap compatible - its based upon the JS and CSS.  Good and stand alone plugin for your daily app or calendar  #DograsWeblog @mrdogra007