A Pen created at CodePen.io. You can find this one at https://codepen.io/minimo/pen/xGbdOZ.

 A little AngluarJS todo app, with some SASS/Compass, and WebSQL database storage !