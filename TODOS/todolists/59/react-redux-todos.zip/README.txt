A Pen created at CodePen.io. You can find this one at https://codepen.io/matthewvincent/pen/GqjKYy.

 Learning up some Redux. My attempt at re-implementing the Redux docs tutorial from memory. Styling for fun. 