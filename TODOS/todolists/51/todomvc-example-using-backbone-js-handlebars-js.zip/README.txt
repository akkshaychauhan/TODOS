A Pen created at CodePen.io. You can find this one at https://codepen.io/zakirt/pen/OPVrvq.

 Simple TodoMVC example I created using Backbone.js & Handlebars.js libraries.