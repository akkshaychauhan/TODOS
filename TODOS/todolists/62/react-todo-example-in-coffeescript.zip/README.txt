A Pen created at CodePen.io. You can find this one at https://codepen.io/tswicegood/pen/WbjLOq.

 This is a port of the [React Todo][1] example into CoffeeScript with a little Foundation styling.

[1]: http://facebook.github.io/react/index.html