A Pen created at CodePen.io. You can find this one at https://codepen.io/tipsoftheday/pen/Iviju.

 A TodoMVC example using AngularJS from http://todomvc.com, a project which offers the same Todo application implemented using MV* concepts in most of the popular JavaScript MV* frameworks of today and helps developers select an MV* framework for structuring and organizing their JavaScript web apps.