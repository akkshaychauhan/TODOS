A Pen created at CodePen.io. You can find this one at https://codepen.io/milabear/pen/moniI.

 Wanted to make a useful todo list that prioritized itself. First time using haml.